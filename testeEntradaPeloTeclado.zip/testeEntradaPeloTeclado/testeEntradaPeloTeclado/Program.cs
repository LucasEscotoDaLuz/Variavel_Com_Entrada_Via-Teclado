﻿using System;

namespace testeEntradaPeloTeclado
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite os seus Dados de Identificação.");

            string nome;
            string genero;
            string cpf;
            int dataDeNascimento;
            string telefone;
            string email;
            string endereco;
            string numero;
            string bairro;
            string cidade;
            string estado;
            string pais;


            Console.Write("Digite o seu nome completo: ");
            nome = Console.ReadLine();

            Console.Write("Digite o gênero que você se identifica: ");
            genero = Console.ReadLine();

            Console.Write("Digite sua data de nascimento (apenas os números e sem espaço): ");
            dataDeNascimento = int.Parse(Console.ReadLine());
            var stringDataDeNascimento = Convert.ToUInt64(dataDeNascimento).ToString(@"00\/00\/0000");

            Console.Write("Digite seu CPF (apenas os números): ");
            cpf = Console.ReadLine();
            var stringCPF = Convert.ToUInt64(cpf).ToString(@"000\.000\.000\-00");
            

            Console.Write("Digite o número de seu telefone com DDD (apenas os números e sem espaço): ");
            telefone = Console.ReadLine();
            var stringTelefone = Convert.ToUInt64(telefone).ToString(@"(00)\-00000\-0000");

            Console.Write("Digite o seu endereço de e-mail: ");
            email = Console.ReadLine();

            Console.Write("Digite o seu Endereço (sem numeração): ");
            endereco = Console.ReadLine();

            Console.WriteLine("Digite o número de sua residência: ");
            numero = Console.ReadLine();


            Console.WriteLine("Digite o bairro de sua residência: ");
            bairro = Console.ReadLine();

            Console.WriteLine("Digite a cidade: ");
            cidade = Console.ReadLine();

            Console.WriteLine("Digite o estado (sigla): ");
            estado = Console.ReadLine();

            Console.WriteLine("Digite o seu país: ");
            pais = Console.ReadLine();


            Console.WriteLine("*************************************************");
            Console.WriteLine("Confira os seus dados: ");
            Console.WriteLine("*************************************************");
            Console.WriteLine("Nome: {0}", nome);
            Console.WriteLine("Gênero: {0}", genero);
            Console.WriteLine("Data de Nascimento {0}: ", stringDataDeNascimento);
            Console.WriteLine("CPF {0}", stringCPF);
            
            Console.WriteLine("*************************************************");
            Console.WriteLine("Datos de Contato: ");
            Console.WriteLine("*************************************************");

            Console.WriteLine("Telefone {0}", stringTelefone);
            Console.WriteLine("E-mail {0}", email);

            Console.WriteLine("*************************************************");
            Console.WriteLine(" Dados de Correspondência: ");
            Console.WriteLine("*************************************************");

            Console.WriteLine("Logradouro: {0}", endereco);
            Console.WriteLine("Número: {0}", numero);
            Console.WriteLine("Bairro: {0}", bairro);
            Console.WriteLine("Cidade: {0}", cidade);
            Console.WriteLine("Estado: {0}", estado);
            Console.WriteLine("País: {0}", pais );




        }
    }
}
;